const { Pool } = require('pg');

const pool = new Pool({
    host: 'localhost',
    user: 'postgres',
    password:'123456',
    database: 'ecommerce5',
    port:5432,
});

module.exports = pool;